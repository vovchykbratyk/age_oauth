from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

from .oauth import get_gis, _default_env_path, _write_template_if_missing, load_env, _config_is_ready, _prompt_for_config


def main() -> int:
    p = argparse.ArgumentParser(prog="age-oauth")
    p.add_argument("--env", default=None, help="Path to env file (default: ARCGIS_OAUTH_ENV or ~/.arcgis/.env)")
    p.add_argument("-v", "--verbose", action="store_true", help="Enable info logging")

    sub = p.add_subparsers(dest="cmd", required=False)

    sub.add_parser("init", help="Create starter env template and prompt for required settings if missing")
    sub.add_parser("login", help="Authenticate (interactive) and cache tokens")
    sub.add_parser("whoami", help="Print authenticated username")

    args = p.parse_args()

    level = logging.INFO if args.verbose else logging.WARNING
    logging.basicConfig(level=level, format="[%(levelname)s] %(message)s")
    log = logging.getLogger("age_oauth")

    env_path = str(Path(args.env or _default_env_path()).expanduser())
    log.info("env file: %s", env_path)

    try:
        # if there's no subcommand, we just log in and create a GIS() (default behavior)
        cmd = args.cmd or "login"

        if cmd == "init":
            _write_template_if_missing(env_path)
            load_env(env_path)
            if not _config_is_ready(env_path):
                print(f"[INFO] Missing required OAuth settings. Please complete: {env_path}")
                _prompt_for_config(env_path)
            print(f"[OK] Initialized: {env_path}")
            return 0

        # login / whoami both need a GIS object
        gis = get_gis(env_path=env_path)

        if cmd == "whoami":
            me = gis.users.me
            print(getattr(me, "username", None) or "unknown")
            return 0

        # cmd == "login"
        print("[OK] GIS object created.")
        return 0

    except KeyboardInterrupt:
        print("\n[ABORTED] Cancelled by user.")
        return 130
    except Exception as ex:
        print(f"[ERROR] {ex}")
        if args.verbose:
            raise
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
