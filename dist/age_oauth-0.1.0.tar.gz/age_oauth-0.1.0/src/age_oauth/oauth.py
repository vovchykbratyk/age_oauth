from __future__ import annotations

import os
import time
import getpass
import logging
from datetime import datetime, timezone, timedelta
from dataclasses import dataclass
from typing import Dict
from urllib.parse import urlencode
from pathlib import Path

import requests
import webbrowser

# silence insecure connection noise... turn off for real world by
# setting OAUTH_VERIFY_SSL to whatever custom CA bundle we use
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

log = logging.getLogger("age_oauth")

# check if python-dotenv is there, use internal fallback if not
try:
    from dotenv import load_dotenv as _dotenv_load  # type: ignore
    from dotenv import set_key as _dotenv_set_key   # type: ignore
    _HAVE_DOTENV = True
except Exception:
    _dotenv_load = None
    _dotenv_set_key = None
    _HAVE_DOTENV = False


# local .env parsing functions
def _strip_quotes(s: str) -> str:
    s = s.strip()
    if len(s) >= 2 and ((s[0] == s[-1]) and s[0] in ("'", '"')):
        return s[1:-1]
    return s


def _quote_env_value(v: str) -> str:
    if v == "" or any(c.isspace() for c in v) or "#" in v:
        return '"' + v.replace('"', '\\"') + '"'
    return v


def _parse_env_file(path: Path) -> Dict[str, str]:
    """
    minimalistic env parser
    """
    data: Dict[str, str] = {}
    if not path.exists():
        return data

    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            continue

        key, value = line.split("=", 1)
        key = key.strip()
        value = _strip_quotes(value.strip())
        if key:
            data[key] = value
    return data


def _load_env_fallback(env_path: str) -> Dict[str, str]:
    """
    loads .env to os.environ if we don't have python-dotenv available.
    does NOT clobber existing environment variables.
    """
    p = Path(env_path).expanduser()
    parsed = _parse_env_file(p)

    for k, v in parsed.items():
        os.environ.setdefault(k, v)

    return parsed


def _set_key_fallback(env_path: str, key: str, value: str) -> None:
    """
    minimalistic .env writer
    """
    p = Path(env_path).expanduser()
    p.parent.mkdir(parents=True, exist_ok=True)

    lines = []
    if p.exists():
        lines = p.read_text(encoding="utf-8").splitlines()

    quoted_val = _quote_env_value(value)
    updated = False
    new_lines = []

    for line in lines:
        stripped = line.lstrip()
        if stripped.startswith("#") or "=" not in line:
            new_lines.append(line)
            continue

        existing_key = line.split("=", 1)[0].strip()
        if existing_key == key:
            new_lines.append(f"{key}={quoted_val}")
            updated = True
        else:
            new_lines.append(line)

    if not updated:
        if new_lines and new_lines[-1].strip() != "":
            new_lines.append("")  # nice separation
        new_lines.append(f"{key}={quoted_val}")

    tmp = p.with_suffix(p.suffix + ".tmp")
    tmp.write_text("\n".join(new_lines) + "\n", encoding="utf-8")
    tmp.replace(p)


def load_env(env_path: str) -> None:
    """
    loader uses python-dotenv when present, falls back to local functions
    """
    env_path = str(Path(env_path).expanduser())
    if _HAVE_DOTENV and _dotenv_load is not None:
        # default override=False, matches our fallback behavior
        _dotenv_load(dotenv_path=env_path)
    else:
        _load_env_fallback(env_path)


def set_env_key(env_path: str, key: str, value: str) -> None:
    """
    setter uses python-dotenv when present, falls back to local functions
    """
    env_path = str(Path(env_path).expanduser())
    if _HAVE_DOTENV and _dotenv_set_key is not None:
        _dotenv_set_key(env_path, key, value)
    else:
        _set_key_fallback(env_path, key, value)


def _to_readable_time(total_seconds: float) -> str:
    """
    reports timespan in human readable format ("H:MM:SS" or "X Days, H:MM:SS")
    """
    try:
        if total_seconds < 0:
            return f"-{_to_readable_time(-total_seconds)}"
        return str(timedelta(seconds=float(total_seconds)))
    except (OverflowError, TypeError, ValueError) as e:
        return f"Input error {total_seconds!r}: {e}"



# env defaults and bootstrap in case it's missing (usually on first run)
_REQUIRED_KEYS = ("PORTAL_URL", "OAUTH_CLIENT_ID", "OAUTH_CLIENT_SECRET")


def _default_env_path() -> str:
    """
    config/token cache file location
    override with ARCGIS_OAUTH_ENV
    """
    override = os.getenv("ARCGIS_OAUTH_ENV", "").strip()
    if override:
        return str(Path(override).expanduser())

    d = Path.home() / ".arcgis"
    d.mkdir(parents=True, exist_ok=True)
    p = d / ".env"
    if p.exists() and p.is_dir():
        raise RuntimeError(f"{p} exists but is a directory; please remove it.")
    return str(p)


def _write_template_if_missing(env_path: str) -> None:
    p = Path(env_path).expanduser()
    p.parent.mkdir(parents=True, exist_ok=True)

    if p.exists():
        return

    template = (
        "# ArcGIS Enterprise OAuth configuration\n"
        "# Fill in the values below (first run will also prompt).\n"
        "# OAUTH_VERIFY_SSL accepts 'true', 'false', or a path to a CA cert.\n"
        "PORTAL_URL=''\n"
        "OAUTH_CLIENT_ID=''\n"
        "OAUTH_CLIENT_SECRET=''\n"
        "OAUTH_VERIFY_SSL=''\n"
        "\n"
        "# Token fields will be written below automatically after first login.\n"
    )
    p.write_text(template, encoding="utf-8")
    log.info("Wrote starter env template: %s", p)


def _config_is_ready(env_path: str) -> bool:
    data = _parse_env_file(Path(env_path).expanduser())
    return all(data.get(k, "").strip() for k in _REQUIRED_KEYS)


def _prompt_for_config(env_path: str) -> None:
    """
    Prompt for the 4 core values. Secret is hidden. SSL may be true/false/path.
    """
    current = _parse_env_file(Path(env_path).expanduser())

    def ask_required(label: str, key: str, secret: bool = False) -> str:
        existing = current.get(key, "").strip()
        if existing:
            return existing

        while True:
            val = getpass.getpass(f"{label}: ").strip() if secret else input(f"{label}: ").strip()
            if val:
                return val
            print("Value is required.")

    portal_url = ask_required("Portal URL (e.g. https://host/portal)", "PORTAL_URL").rstrip("/")
    client_id = ask_required("OAuth Client ID", "OAUTH_CLIENT_ID")
    client_secret = ask_required("OAuth Client Secret", "OAUTH_CLIENT_SECRET", secret=True)

    ssl_existing = current.get("OAUTH_VERIFY_SSL", "").strip()
    if ssl_existing:
        ssl_val = ssl_existing
    else:
        ssl_val = input("Verify SSL? [true/false/path] (default: true): ").strip() or "true"

    set_env_key(env_path, "PORTAL_URL", portal_url)
    set_env_key(env_path, "OAUTH_CLIENT_ID", client_id)
    set_env_key(env_path, "OAUTH_CLIENT_SECRET", client_secret)
    set_env_key(env_path, "OAUTH_VERIFY_SSL", ssl_val)

    # Make immediately available in current process
    os.environ["PORTAL_URL"] = portal_url
    os.environ["OAUTH_CLIENT_ID"] = client_id
    os.environ["OAUTH_CLIENT_SECRET"] = client_secret
    os.environ["OAUTH_VERIFY_SSL"] = ssl_val


# oauth mechanics
@dataclass
class OAuthConfig:
    portal_url: str
    client_id: str
    client_secret: str
    redirect_uri: str = "urn:ietf:wg:oauth:2.0:oob"
    scope: str = "portal:user:read,portal:item:read,portal:group:read"
    env_path: str = ""          # single canonical env path
    verify_ssl: bool = True


class AGEOAuth:
    """
    ArcGIS Enterprise OAuth Helper
    """

    def __init__(self, config: OAuthConfig):
        self.config = config
        self.env_path = str(Path(self.config.env_path or _default_env_path()).expanduser())

        log.info("env file: %s", self.env_path)

        # Load env (single file)
        load_env(self.env_path)

        # verify setting: bool or path
        env_verify = os.getenv("OAUTH_VERIFY_SSL", "").strip()
        if not env_verify:
            self.verify_ssl = bool(config.verify_ssl)
        else:
            v = env_verify.lower()
            if v in ("false", "0", "no", "off"):
                self.verify_ssl = False
            elif v in ("true", "1", "yes", "on"):
                self.verify_ssl = True
            else:
                if os.path.exists(env_verify):
                    self.verify_ssl = env_verify
                else:
                    raise ValueError(
                        f"OAUTH_VERIFY_SSL set to {env_verify!r} but is not a boolean or valid path value"
                    )

        if isinstance(self.verify_ssl, str):
            log.info("SSL verification using custom CA: %s", self.verify_ssl)

        # populate from env (with config defaults)
        self.portal_url = os.getenv("PORTAL_URL", config.portal_url).rstrip("/")
        self.client_id = os.getenv("OAUTH_CLIENT_ID", config.client_id)
        self.client_secret = os.getenv("OAUTH_CLIENT_SECRET", config.client_secret)
        self.redirect_uri = os.getenv("OAUTH_REDIRECT_URI", config.redirect_uri)
        self.scope = os.getenv("OAUTH_SCOPE", config.scope)

        # token state from env (won't be there on first run)
        self._access_token = os.getenv("OAUTH_ACCESS_TOKEN", "")
        self._refresh_token = os.getenv("OAUTH_REFRESH_TOKEN", "")
        self._expires_at = float(os.getenv("OAUTH_TOKEN_EXPIRES_AT") or 0)
        self._username = os.getenv("OAUTH_USERNAME", "")

        self.authorize_url = f"{self.portal_url}/sharing/rest/oauth2/authorize"
        self.token_url = f"{self.portal_url}/sharing/rest/oauth2/token"

    @property
    def access_token(self) -> str:
        if not self._access_token or self.is_expired():
            self.refresh_or_login()
        return self._access_token

    @property
    def portal(self) -> str:
        return self.portal_url

    def is_expired(self, skew_seconds: int = 60) -> bool:
        return time.time() >= (self._expires_at - skew_seconds)

    def refresh_or_login(self) -> None:
        if self._refresh_token:
            try:
                self._refresh_access_token()
                return
            except Exception as ex:
                log.warning("Refresh failed: %r – falling back to interactive login.", ex)
        self._interactive_login()

    def _interactive_login(self) -> None:
        params = {
            "client_id": self.client_id,
            "response_type": "code",
            "redirect_uri": self.redirect_uri,
            "scope": self.scope,
        }
        url = f"{self.authorize_url}?{urlencode(params)}"

        print("Opening browser for ArcGIS Enterprise OAuth sign-in...")
        print(f"If the browser does not open, copy/paste this URL manually:\n{url}\n")

        webbrowser.open(url)

        print("After signing in, your portal will show an authorization code.")
        code = input("Paste the authorization code here: ").strip()
        if not code:
            raise RuntimeError("No authorization code entered.")

        print("Exchanging code for tokens...")
        self._exchange_code_for_tokens(code)

    def _exchange_code_for_tokens(self, code: str) -> None:
        data = {
            "client_id": self.client_id,
            "client_secret": self.client_secret,
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": self.redirect_uri,
        }
        self._request_token(data)

    def _refresh_access_token(self) -> None:
        if not self._refresh_token:
            raise RuntimeError("No refresh_token available for refresh.")
        data = {
            "client_id": self.client_id,
            "client_secret": self.client_secret,
            "grant_type": "refresh_token",
            "refresh_token": self._refresh_token,
        }
        print("Refreshing access token using refresh_token...")
        self._request_token(data)

    def _request_token(self, data: Dict[str, str]) -> None:
        resp = requests.post(self.token_url, data=data, timeout=30, verify=self.verify_ssl)
        if not resp.ok:
            raise RuntimeError(f"Token endpoint error: {resp.status_code} {resp.text}")

        payload = resp.json()
        self._access_token = payload["access_token"]
        expires_in = float(payload.get("expires_in", 3600))
        self._expires_at = time.time() + expires_in

        if "refresh_token" in payload:
            self._refresh_token = payload["refresh_token"]
        if "username" in payload:
            self._username = payload["username"]
        if "scope" in payload:
            self.scope = payload["scope"]

        expires_in_readable = _to_readable_time(expires_in)
        print(f"New access_token acquired! Expires in: {expires_in_readable}")
        if self._username:
            print(f"Token is for user: {self._username}")

        self._persist()

    def _persist(self) -> None:
        """
        Persist everything into the single canonical env file.
        """
        env_path = self.env_path

        def save(key: str, value: object) -> None:
            s = str(value)
            os.environ[key] = s
            set_env_key(env_path, key, s)

        # core
        save("PORTAL_URL", self.portal_url)
        save("OAUTH_CLIENT_ID", self.client_id)
        save("OAUTH_CLIENT_SECRET", self.client_secret)
        env_verify = os.getenv("OAUTH_VERIFY_SSL", "").strip()
        if env_verify:
            save("OAUTH_VERIFY_SSL", env_verify)

        # user/token-ish
        save("OAUTH_REDIRECT_URI", self.redirect_uri)
        save("OAUTH_SCOPE", self.scope)
        save("OAUTH_ACCESS_TOKEN", self._access_token)
        save("OAUTH_REFRESH_TOKEN", self._refresh_token)
        save("OAUTH_TOKEN_EXPIRES_AT", self._expires_at)  # epoch
        iso_expiration = datetime.fromtimestamp(self._expires_at, tz=timezone.utc).isoformat()
        save("OAUTH_TOKEN_EXPIRES_AT_UTC", iso_expiration)
        if self._username:
            save("OAUTH_USERNAME", self._username)


def get_gis(env_path: str | None = None):
    """
    Convenience wrapper: bootstrap config if needed, negotiate token, return GIS.

    env_path defaults to ~/.arcgis/.env (override ARCGIS_OAUTH_ENV).
    """
    from arcgis.gis import GIS

    env_path = str(Path(env_path or _default_env_path()).expanduser())

    # First-run bootstrap
    _write_template_if_missing(env_path)
    load_env(env_path)

    if not _config_is_ready(env_path):
        print(f"[INFO] Missing required OAuth settings. Please complete: {env_path}")
        _prompt_for_config(env_path)
        load_env(env_path)

    portal_url = os.getenv("PORTAL_URL", "").rstrip("/")
    client_id = os.getenv("OAUTH_CLIENT_ID", "")
    client_secret = os.getenv("OAUTH_CLIENT_SECRET", "")

    if not portal_url or not client_id or not client_secret:
        raise RuntimeError(f"Core OAuth settings still incomplete in: {env_path}")

    cfg = OAuthConfig(
        portal_url=portal_url,
        client_id=client_id,
        client_secret=client_secret,
        env_path=env_path,
    )
    auth = AGEOAuth(cfg)

    # GIS SSL handling: verify_cert bool + ca_bundles path when needed
    gis_kwargs = {}
    v = auth.verify_ssl
    if isinstance(v, bool):
        gis_verify = v
    else:
        ca_path = str(Path(v).expanduser())
        gis_verify = True
        gis_kwargs["ca_bundles"] = ca_path

    return GIS(auth.portal_url, token=auth.access_token, verify_cert=gis_verify, **gis_kwargs)
